"use client";
import { useRef, useState } from "react";
import { createClient } from "@/lib/supabase/client";

const types = ["text","photo","voice","video"] as const;

export function CreatePost() {
  const supabase = createClient();
  const [type, setType] = useState<typeof types[number]>("text");
  const [body, setBody] = useState("");
  const [file, setFile] = useState<File | null>(null);
  const [recording, setRecording] = useState(false);
  const [status, setStatus] = useState("");
  const recorderRef = useRef<MediaRecorder | null>(null);
  const chunksRef = useRef<Blob[]>([]);

  async function startRecording() {
    const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
    const recorder = new MediaRecorder(stream);
    chunksRef.current = [];
    recorder.ondataavailable = e => e.data.size && chunksRef.current.push(e.data);
    recorder.onstop = () => {
      const blob = new Blob(chunksRef.current, { type: "audio/webm" });
      setFile(new File([blob], `voice-${Date.now()}.webm`, { type: "audio/webm" }));
      stream.getTracks().forEach(t => t.stop());
    };
    recorder.start();
    recorderRef.current = recorder;
    setRecording(true);
  }

  function stopRecording() {
    recorderRef.current?.stop();
    setRecording(false);
  }

  async function submit(e: React.FormEvent) {
    e.preventDefault();
    setStatus("Posting...");
    const { data: { user } } = await supabase.auth.getUser();
    if (!user) { setStatus("Please log in first."); return; }
    if (type !== "text" && !file) { setStatus("Add or record media first."); return; }
    let media_url: string | null = null;

    if (file) {
      const ext = file.name.split(".").pop() || "bin";
      const path = `${user.id}/${crypto.randomUUID()}.${ext}`;
      const { error: uploadError } = await supabase.storage.from("gista-media").upload(path, file, { upsert: false });
      if (uploadError) { setStatus(uploadError.message); return; }
      const { data } = supabase.storage.from("gista-media").getPublicUrl(path);
      media_url = data.publicUrl;
    }

    const { error } = await supabase.from("posts").insert({
      user_id: user.id,
      type,
      body: body.trim() || null,
      media_url
    });
    if (error) setStatus(error.message);
    else { setBody(""); setFile(null); setStatus("Posted!"); }
  }

  return (
    <form className="card composer" onSubmit={submit}>
      <div className="tabs">{types.map(t => <button type="button" key={t} className={type===t?"active":""} onClick={()=>{setType(t);setFile(null);}}>{t[0].toUpperCase()+t.slice(1)}</button>)}</div>
      <textarea value={body} onChange={e=>setBody(e.target.value)} placeholder="What do you want to talk about?" />
      {type === "photo" && <input style={{marginTop:12}} type="file" accept="image/*" onChange={e=>setFile(e.target.files?.[0] || null)} />}
      {type === "video" && <input style={{marginTop:12}} type="file" accept="video/*" onChange={e=>setFile(e.target.files?.[0] || null)} />}
      {type === "voice" && <div style={{marginTop:12}}><button type="button" className={recording ? "secondary":"primary"} onClick={recording ? stopRecording : startRecording}>{recording ? "Stop recording" : "Record voice (60s max)"}</button>{file && <span className="muted" style={{marginLeft:10}}>{file.name}</span>}</div>}
      {type === "video" && <div className="muted" style={{marginTop:8}}>MVP limit: keep videos at 60 seconds or less.</div>}
      <div className="between" style={{marginTop:14}}><span className="muted">{status}</span><button className="primary">Post</button></div>
    </form>
  );
}