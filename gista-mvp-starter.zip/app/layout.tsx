import "./globals.css";
import type { Metadata } from "next";

export const metadata: Metadata = {
  title: "Gista — Every Post Starts a Conversation",
  description: "A conversation-first social platform."
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return <>{children}</>;
}