"use client";
import { useState } from "react";
import { createClient } from "@/lib/supabase/client";
import { Logo } from "@/components/logo";
import Link from "next/link";
import { useRouter } from "next/navigation";

export default function Login() {
  const supabase = createClient(); const router = useRouter();
  const [email,setEmail]=useState(""); const [password,setPassword]=useState(""); const [error,setError]=useState("");
  async function submit(e:React.FormEvent){e.preventDefault();setError("");const {error}=await supabase.auth.signInWithPassword({email,password});if(error)setError(error.message);else router.push("/");}
  return <main className="auth"><div className="card auth-card"><div className="auth-logo"><Logo large/></div><h1>Welcome to Gista</h1><p>Every Post Starts a Conversation.</p><form className="form-stack" onSubmit={submit}><input className="input" type="email" placeholder="Email" value={email} onChange={e=>setEmail(e.target.value)} required/><input className="input" type="password" placeholder="Password" value={password} onChange={e=>setPassword(e.target.value)} required/><button className="primary">Log in</button>{error&&<div className="error">{error}</div>}</form><p><Link href="/signup" style={{color:"var(--purple)",fontWeight:800}}>Create an account</Link></p></div></main>;
}