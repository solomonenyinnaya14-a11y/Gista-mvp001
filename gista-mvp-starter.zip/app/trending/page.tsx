import { Nav } from "@/components/nav";
import { createClient } from "@/lib/supabase/server";
import { PostCard } from "@/components/post-card";
import { redirect } from "next/navigation";

export default async function Trending(){const supabase=await createClient();const {data:{user}}=await supabase.auth.getUser();if(!user)redirect("/login");const {data:posts}=await supabase.from("posts").select("id,user_id,type,body,media_url,created_at,profiles!posts_user_id_fkey(username,display_name,avatar_url)").order("created_at",{ascending:false}).limit(20);return <><Nav/><main className="page"><div className="container" style={{maxWidth:760}}><h1>Trending Conversations</h1><p className="muted">MVP version: recent posts are surfaced here. We can add real ranking after user data exists.</p>{posts?.map((p:any)=><PostCard key={p.id} post={p} currentUserId={user.id}/>)}</div></main></>}