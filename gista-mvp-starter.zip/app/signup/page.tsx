"use client";
import { useState } from "react";
import { createClient } from "@/lib/supabase/client";
import { Logo } from "@/components/logo";
import Link from "next/link";
import { useRouter } from "next/navigation";

export default function Signup() {
  const supabase=createClient(); const router=useRouter();
  const [email,setEmail]=useState(""); const [password,setPassword]=useState(""); const [username,setUsername]=useState(""); const [error,setError]=useState(""); const [done,setDone]=useState(false);
  async function submit(e:React.FormEvent){e.preventDefault();setError("");const {data,error}=await supabase.auth.signUp({email,password,options:{data:{username}}});if(error)setError(error.message);else if(data.user){setDone(true);setTimeout(()=>router.push("/"),1200);}}
  return <main className="auth"><div className="card auth-card"><div className="auth-logo"><Logo large/></div><h1>Join Gista</h1><p>Create your account and start a conversation.</p><form className="form-stack" onSubmit={submit}><input className="input" placeholder="Username" value={username} onChange={e=>setUsername(e.target.value.replace(/\s/g,"").toLowerCase())} required/><input className="input" type="email" placeholder="Email" value={email} onChange={e=>setEmail(e.target.value)} required/><input className="input" type="password" placeholder="Password (6+ characters)" minLength={6} value={password} onChange={e=>setPassword(e.target.value)} required/><button className="primary">Create account</button>{error&&<div className="error">{error}</div>}{done&&<div className="success">Account created. Check your email if confirmation is enabled.</div>}</form><p><Link href="/login" style={{color:"var(--purple)",fontWeight:800}}>Already have an account? Log in</Link></p></div></main>;
}