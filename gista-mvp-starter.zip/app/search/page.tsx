"use client";
import { useState } from "react";
import { createClient } from "@/lib/supabase/client";
import { Nav } from "@/components/nav";
import Link from "next/link";

export default function SearchPage(){const supabase=createClient();const [q,setQ]=useState("");const [results,setResults]=useState<any[]>([]);
async function search(e:React.FormEvent){e.preventDefault();const term=q.trim();if(!term){setResults([]);return;}const {data}=await supabase.from("profiles").select("id,username,display_name,avatar_url").or(`username.ilike.%${term}%,display_name.ilike.%${term}%`).limit(20);setResults(data||[]);}
return <><Nav/><main className="page"><div className="container" style={{maxWidth:760}}><h1>Search</h1><form className="search-row" onSubmit={search}><input className="input" value={q} onChange={e=>setQ(e.target.value)} placeholder="Search Gista creators..."/><button className="primary">Search</button></form><div className="card" style={{padding:18}}>{results.map(r=><Link key={r.id} href={`/u/${r.username}`} className="creator"><div className="row"><img className="avatar sm" src={r.avatar_url||"/avatar.svg"} alt=""/><div><b>{r.display_name}</b><div className="muted">@{r.username}</div></div></div><span className="small-btn">View</span></Link>)}{!results.length&&<div className="empty">Search for a creator by name or username.</div>}</div></div></main></> }