import { Nav } from "@/components/nav";
import { PostCard } from "@/components/post-card";
import { createClient } from "@/lib/supabase/server";
import { redirect } from "next/navigation";

export default async function SubscriptionsPage(){
  const supabase=await createClient(); const {data:{user}}=await supabase.auth.getUser(); if(!user)redirect("/login");
  const {data:subs}=await supabase.from("subscriptions").select("creator_id").eq("subscriber_id",user.id);
  const ids=(subs||[]).map(s=>s.creator_id);
  const {data:posts}=ids.length?await supabase.from("posts").select("id,user_id,type,body,media_url,created_at,profiles!posts_user_id_fkey(username,display_name,avatar_url)").in("user_id",ids).order("created_at",{ascending:false}).limit(30):{data:[]};
  return <><Nav/><main className="page"><div className="container" style={{maxWidth:760}}><div className="tabs"><a href="/" style={{flex:1,textAlign:"center",padding:11,color:"#777"}}>Discover</a><button className="active">Subscriptions</button><a href="/trending" style={{flex:1,textAlign:"center",padding:11,color:"#777"}}>Trending</a></div>{posts?.map((p:any)=><PostCard key={p.id} post={p} currentUserId={user.id}/>)}{!posts?.length&&<div className="card empty">Your subscriptions will appear here. Discover creators and subscribe to them.</div>}</div></main></>;
}