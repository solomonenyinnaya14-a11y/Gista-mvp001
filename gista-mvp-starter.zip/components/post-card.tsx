"use client";
import { useEffect, useState } from "react";
import { Bookmark, Heart, MessageCircle, Share2, Play } from "lucide-react";
import { createClient } from "@/lib/supabase/client";

type Post = {
  id: string; user_id: string; type: "text"|"photo"|"voice"|"video";
  body: string | null; media_url: string | null; created_at: string;
  profiles?: { username: string; display_name: string; avatar_url: string | null };
};

export function PostCard({ post, currentUserId }: { post: Post; currentUserId?: string }) {
  const supabase = createClient();
  const [liked, setLiked] = useState(false);
  const [saved, setSaved] = useState(false);
  const [likes, setLikes] = useState(0);
  const [responses, setResponses] = useState(0);
  const [subscribed, setSubscribed] = useState(false);
  const [busy, setBusy] = useState(false);

  useEffect(() => {
    async function load() {
      const { count: lc } = await supabase.from("likes").select("*", { count: "exact", head: true }).eq("post_id", post.id);
      const { count: rc } = await supabase.from("responses").select("*", { count: "exact", head: true }).eq("post_id", post.id);
      setLikes(lc ?? 0); setResponses(rc ?? 0);
      if (!currentUserId) return;
      const { data: l } = await supabase.from("likes").select("post_id").eq("post_id", post.id).eq("user_id", currentUserId).maybeSingle();
      const { data: s } = await supabase.from("saved_posts").select("post_id").eq("post_id", post.id).eq("user_id", currentUserId).maybeSingle();
      const { data: sub } = await supabase.from("subscriptions").select("creator_id").eq("creator_id", post.user_id).eq("subscriber_id", currentUserId).maybeSingle();
      setLiked(!!l); setSaved(!!s); setSubscribed(!!sub);
    }
    load();
  }, [post.id, post.user_id, currentUserId]);

  async function toggleLike() {
    if (!currentUserId || busy) return;
    setBusy(true);
    if (liked) {
      await supabase.from("likes").delete().eq("post_id", post.id).eq("user_id", currentUserId);
      setLikes(v => Math.max(0, v - 1)); setLiked(false);
    } else {
      await supabase.from("likes").insert({ post_id: post.id, user_id: currentUserId });
      setLikes(v => v + 1); setLiked(true);
    }
    setBusy(false);
  }

  async function toggleSave() {
    if (!currentUserId) return;
    if (saved) {
      await supabase.from("saved_posts").delete().eq("post_id", post.id).eq("user_id", currentUserId);
      setSaved(false);
    } else {
      await supabase.from("saved_posts").insert({ post_id: post.id, user_id: currentUserId });
      setSaved(true);
    }
  }

  async function toggleSubscribe() {
    if (!currentUserId || currentUserId === post.user_id) return;
    if (subscribed) {
      await supabase.from("subscriptions").delete().eq("creator_id", post.user_id).eq("subscriber_id", currentUserId);
      setSubscribed(false);
    } else {
      await supabase.from("subscriptions").insert({ creator_id: post.user_id, subscriber_id: currentUserId });
      setSubscribed(true);
    }
  }

  async function share() {
    const url = `${window.location.origin}/post/${post.id}`;
    if (navigator.share) await navigator.share({ title: "Gista conversation", url });
    else await navigator.clipboard.writeText(url);
  }

  return (
    <article className="card feed-card">
      <div className="between">
        <div className="row">
          <img className="avatar" src={post.profiles?.avatar_url || "/avatar.svg"} alt="" />
          <div><b>{post.profiles?.display_name || "Gista creator"}</b><div className="muted">@{post.profiles?.username || "user"} · {new Date(post.created_at).toLocaleString()}</div></div>
        </div>
        <button className="action">•••</button>
      </div>

      {post.body && <div className="post-text">{post.body}</div>}

      {post.type === "photo" && post.media_url && <img className="media" src={post.media_url} alt={post.body || "Gista photo"} />}
      {post.type === "video" && post.media_url && <video className="media" src={post.media_url} controls playsInline />}
      {post.type === "voice" && post.media_url && <audio className="audio-player" src={post.media_url} controls />}

      <div className="actions">
        <button className="action" onClick={toggleLike}><Heart size={19} fill={liked ? "currentColor" : "none"}/>{likes}</button>
        <a className="action" href={`/post/${post.id}`}><MessageCircle size={19}/>{responses}</a>
        <button className="action" onClick={share}><Share2 size={18}/></button>
        <button className="action" onClick={toggleSave}><Bookmark size={18} fill={saved ? "currentColor" : "none"}/></button>
        {currentUserId && currentUserId !== post.user_id && <button className="small-btn" onClick={toggleSubscribe}>{subscribed ? "Subscribed" : "Subscribe"}</button>}
      </div>
      <div style={{marginTop:12}}>
        <a className="primary" href={`/post/${post.id}`} style={{display:"inline-block"}}>Join Conversation</a>
      </div>
    </article>
  );
}