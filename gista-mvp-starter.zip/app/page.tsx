import { Nav } from "@/components/nav";
import { PostCard } from "@/components/post-card";
import { createClient } from "@/lib/supabase/server";
import { redirect } from "next/navigation";
import Link from "next/link";

export default async function Home() {
  const supabase = await createClient();
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) redirect("/login");

  const { data: posts } = await supabase
    .from("posts")
    .select("id,user_id,type,body,media_url,created_at,profiles!posts_user_id_fkey(username,display_name,avatar_url)")
    .order("created_at", { ascending: false })
    .limit(30);

  return <div className="app-shell"><Nav/><main className="page"><div className="container grid"><section>
    <div className="tabs"><button className="active">Discover</button><Link href="/subscriptions" style={{flex:1,textAlign:"center",padding:11,fontWeight:700,color:"#777"}}>Subscriptions</Link><Link href="/trending" style={{flex:1,textAlign:"center",padding:11,fontWeight:700,color:"#777"}}>Trending</Link></div>
    {posts?.map((post:any)=><PostCard key={post.id} post={post} currentUserId={user.id}/>)} 
    {!posts?.length && <div className="card empty">No posts yet. Be the first to start a conversation.</div>}
  </section><aside className="sidebar"><div className="card"><h3>Gista</h3><p className="muted">Discover creators you don't know, then subscribe to the ones you want to hear from.</p><Link className="primary" href="/create" style={{display:"inline-block",marginTop:8}}>Start a conversation</Link></div></aside></div></main></div>;
}