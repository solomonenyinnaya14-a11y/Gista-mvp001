import { Nav } from "@/components/nav";
import { PostCard } from "@/components/post-card";
import { createClient } from "@/lib/supabase/server";
import { redirect } from "next/navigation";

export default async function ProfilePage() {
  const supabase=await createClient(); const {data:{user}}=await supabase.auth.getUser(); if(!user) redirect("/login");
  const {data:p}=await supabase.from("profiles").select("*").eq("id",user.id).single();
  const {count:subs}=await supabase.from("subscriptions").select("*",{count:"exact",head:true}).eq("creator_id",user.id);
  const {data:posts}=await supabase.from("posts").select("id,user_id,type,body,media_url,created_at,profiles!posts_user_id_fkey(username,display_name,avatar_url)").eq("user_id",user.id).order("created_at",{ascending:false}).limit(20);
  return <><Nav/><main className="page"><div className="container" style={{maxWidth:820}}><section className="card profile-hero"><div className="profile-cover"/><div className="profile-main"><img className="profile-avatar" src={p?.avatar_url||"/avatar.svg"} alt=""/><div className="between"><div><h1 style={{margin:"8px 0 2px"}}>{p?.display_name||"Gista Creator"}</h1><div className="muted">@{p?.username}</div><p>{p?.bio||"Every post starts a conversation."}</p></div><form action="/auth/signout" method="post"><button className="secondary">Log out</button></form></div><div className="stats"><div className="stat"><b>{posts?.length||0}</b><span>Posts</span></div><div className="stat"><b>{subs||0}</b><span>Subscribers</span></div><div className="stat"><b>—</b><span>Conversations</span></div></div></div></section>{posts?.map((post:any)=><PostCard key={post.id} post={post} currentUserId={user.id}/>)}</div></main></>;
}