import { Nav } from "@/components/nav";
import { createClient } from "@/lib/supabase/server";
import { notFound, redirect } from "next/navigation";
import { Conversation } from "@/components/conversation";

export default async function PostPage({params}:{params:Promise<{id:string}>}) {
  const {id}=await params; const supabase=await createClient();
  const {data:{user}}=await supabase.auth.getUser(); if(!user) redirect("/login");
  const {data:post}=await supabase.from("posts").select("id,user_id,type,body,media_url,created_at,profiles!posts_user_id_fkey(username,display_name,avatar_url)").eq("id",id).single();
  if(!post) notFound();
  const {data:responses}=await supabase.from("responses").select("id,user_id,type,body,media_url,created_at,profiles!responses_user_id_fkey(username,display_name,avatar_url)").eq("post_id",id).order("created_at",{ascending:true});
  return <><Nav/><main className="page"><div className="container" style={{maxWidth:760}}><Conversation post={post as any} responses={(responses||[]) as any} userId={user.id}/></div></main></>;
}