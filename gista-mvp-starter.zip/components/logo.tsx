export function Logo({ large = false }: { large?: boolean }) {
  return (
    <div className="brand" style={large ? { fontSize: 42 } : undefined}>
      <div className="logo" style={large ? { width: 58, height: 58, borderRadius: 20 } : undefined}>G</div>
      Gista
    </div>
  );
}