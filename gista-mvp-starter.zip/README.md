# Gista MVP

Gista is a conversation-first social app.

## MVP
- Discover feed
- Subscriptions feed
- Text, photo, voice and 60-second video posts
- Text and voice responses
- Likes, saves, shares
- Subscribe/subscriber count
- Search
- Trending
- Notifications
- Profiles
- Basic moderation foundation

## Stack
- Next.js App Router
- TypeScript
- Supabase Auth + Postgres + Storage
- Vercel deployment
- Plain CSS for the UI

## 1. Supabase
Create a project, then open SQL Editor and run `supabase/schema.sql`.

Copy the Project URL and Publishable Key into `.env.local`:

NEXT_PUBLIC_SUPABASE_URL=...
NEXT_PUBLIC_SUPABASE_PUBLISHABLE_KEY=...

Supabase's current Next.js guidance uses `@supabase/ssr` for cookie-based SSR auth.

## 2. Run locally
npm install
npm run dev

Open http://localhost:3000

## 3. GitHub
Create a GitHub repository, then:

git init
git add .
git commit -m "Build Gista MVP"
git branch -M main
git remote add origin https://github.com/YOUR_USERNAME/gista-mvp.git
git push -u origin main

## 4. Vercel
Import the GitHub repository into Vercel.

Add the same two environment variables in:
Project Settings -> Environment Variables

Then deploy.

## Important
This is an MVP foundation, not a production-scale social network. Before public launch, add stronger moderation, media validation/compression, rate limits, analytics, notification triggers, and production-grade storage/CDN decisions.
