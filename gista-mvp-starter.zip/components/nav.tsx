"use client";
import Link from "next/link";
import { Bell, Home, Plus, Search, User } from "lucide-react";

export function Nav() {
  return (
    <>
      <header className="topbar">
        <div className="container topbar-inner">
          <Link href="/"><div className="brand"><div className="logo">G</div>Gista</div></Link>
          <nav className="nav">
            <Link href="/"><Home size={18}/><span>Home</span></Link>
            <Link href="/search"><Search size={18}/><span>Search</span></Link>
            <Link href="/create"><Plus size={18}/><span>Create</span></Link>
            <Link href="/notifications"><Bell size={18}/><span>Notifications</span></Link>
            <Link href="/profile"><User size={18}/><span>Profile</span></Link>
          </nav>
        </div>
      </header>
      <nav className="mobile-nav">
        <Link href="/"><Home size={21}/><span>Home</span></Link>
        <Link href="/search"><Search size={21}/><span>Search</span></Link>
        <Link href="/create" className="create"><Plus size={25}/></Link>
        <Link href="/notifications"><Bell size={21}/><span>Notifications</span></Link>
        <Link href="/profile"><User size={21}/><span>Profile</span></Link>
      </nav>
    </>
  );
}