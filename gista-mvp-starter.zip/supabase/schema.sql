-- Gista MVP database
create extension if not exists pgcrypto;

create table if not exists public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  username text unique not null,
  display_name text not null default 'Gista User',
  bio text default 'Every post starts a conversation.',
  avatar_url text,
  created_at timestamptz not null default now()
);

create table if not exists public.posts (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references public.profiles(id) on delete cascade,
  type text not null check (type in ('text','photo','voice','video')),
  body text,
  media_url text,
  created_at timestamptz not null default now()
);

create table if not exists public.responses (
  id uuid primary key default gen_random_uuid(),
  post_id uuid not null references public.posts(id) on delete cascade,
  user_id uuid not null references public.profiles(id) on delete cascade,
  type text not null check (type in ('text','voice')),
  body text,
  media_url text,
  created_at timestamptz not null default now()
);

create table if not exists public.likes (
  user_id uuid not null references public.profiles(id) on delete cascade,
  post_id uuid not null references public.posts(id) on delete cascade,
  created_at timestamptz not null default now(),
  primary key (user_id, post_id)
);

create table if not exists public.saved_posts (
  user_id uuid not null references public.profiles(id) on delete cascade,
  post_id uuid not null references public.posts(id) on delete cascade,
  created_at timestamptz not null default now(),
  primary key (user_id, post_id)
);

create table if not exists public.subscriptions (
  subscriber_id uuid not null references public.profiles(id) on delete cascade,
  creator_id uuid not null references public.profiles(id) on delete cascade,
  created_at timestamptz not null default now(),
  primary key (subscriber_id, creator_id),
  check (subscriber_id <> creator_id)
);

create table if not exists public.notifications (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references public.profiles(id) on delete cascade,
  actor_id uuid references public.profiles(id) on delete set null,
  title text not null,
  body text,
  read boolean not null default false,
  created_at timestamptz not null default now()
);

create table if not exists public.reports (
  id uuid primary key default gen_random_uuid(),
  reporter_id uuid not null references public.profiles(id) on delete cascade,
  post_id uuid references public.posts(id) on delete cascade,
  response_id uuid references public.responses(id) on delete cascade,
  reported_user_id uuid references public.profiles(id) on delete cascade,
  reason text not null,
  created_at timestamptz not null default now()
);

-- Create a profile automatically when a user signs up.
create or replace function public.handle_new_user()
returns trigger
language plpgsql
security definer set search_path = public
as $$
declare
  desired_username text;
begin
  desired_username := lower(coalesce(new.raw_user_meta_data->>'username', split_part(new.email, '@', 1)));
  desired_username := regexp_replace(desired_username, '[^a-z0-9_]', '', 'g');
  if desired_username = '' then desired_username := 'user'; end if;

  insert into public.profiles(id, username, display_name)
  values(new.id, desired_username || '_' || substr(new.id::text, 1, 5), coalesce(new.raw_user_meta_data->>'username', 'Gista User'))
  on conflict (id) do nothing;
  return new;
end;
$$;

drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created
after insert on auth.users
for each row execute procedure public.handle_new_user();

-- RLS
alter table public.profiles enable row level security;
alter table public.posts enable row level security;
alter table public.responses enable row level security;
alter table public.likes enable row level security;
alter table public.saved_posts enable row level security;
alter table public.subscriptions enable row level security;
alter table public.notifications enable row level security;
alter table public.reports enable row level security;

create policy "profiles are public" on public.profiles for select using (true);
create policy "users update own profile" on public.profiles for update using (auth.uid() = id);

create policy "posts are public" on public.posts for select using (true);
create policy "users create own posts" on public.posts for insert with check (auth.uid() = user_id);
create policy "users update own posts" on public.posts for update using (auth.uid() = user_id);
create policy "users delete own posts" on public.posts for delete using (auth.uid() = user_id);

create policy "responses are public" on public.responses for select using (true);
create policy "users create own responses" on public.responses for insert with check (auth.uid() = user_id);
create policy "users delete own responses" on public.responses for delete using (auth.uid() = user_id);

create policy "likes are public" on public.likes for select using (true);
create policy "users create own likes" on public.likes for insert with check (auth.uid() = user_id);
create policy "users delete own likes" on public.likes for delete using (auth.uid() = user_id);

create policy "users see own saves" on public.saved_posts for select using (auth.uid() = user_id);
create policy "users create own saves" on public.saved_posts for insert with check (auth.uid() = user_id);
create policy "users delete own saves" on public.saved_posts for delete using (auth.uid() = user_id);

create policy "subscriptions are public" on public.subscriptions for select using (true);
create policy "users subscribe as themselves" on public.subscriptions for insert with check (auth.uid() = subscriber_id);
create policy "users unsubscribe as themselves" on public.subscriptions for delete using (auth.uid() = subscriber_id);

create policy "users see own notifications" on public.notifications for select using (auth.uid() = user_id);
create policy "users report content" on public.reports for insert with check (auth.uid() = reporter_id);

-- Public media bucket for MVP.
insert into storage.buckets (id, name, public)
values ('gista-media', 'gista-media', true)
on conflict (id) do update set public = true;

create policy "public can view gista media"
on storage.objects for select
using (bucket_id = 'gista-media');

create policy "authenticated users can upload gista media"
on storage.objects for insert
to authenticated
with check (bucket_id = 'gista-media');

create policy "users can delete their gista media"
on storage.objects for delete
to authenticated
using (bucket_id = 'gista-media' and (storage.foldername(name))[1] = auth.uid()::text);

-- Useful indexes
create index if not exists posts_created_at_idx on public.posts(created_at desc);
create index if not exists posts_user_id_idx on public.posts(user_id);
create index if not exists responses_post_id_idx on public.responses(post_id);
create index if not exists subscriptions_creator_idx on public.subscriptions(creator_id);
create index if not exists subscriptions_subscriber_idx on public.subscriptions(subscriber_id);
