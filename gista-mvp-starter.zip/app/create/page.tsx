import { Nav } from "@/components/nav";
import { CreatePost } from "@/components/create-post";
import { createClient } from "@/lib/supabase/server";
import { redirect } from "next/navigation";

export default async function CreatePage() {
  const supabase=await createClient(); const {data:{user}}=await supabase.auth.getUser(); if(!user) redirect("/login");
  return <><Nav/><main className="page"><div className="container" style={{maxWidth:760}}><h1>Create</h1><p className="muted">Text, photo, voice or 60-second video — every post starts a conversation.</p><CreatePost/></div></main></>;
}